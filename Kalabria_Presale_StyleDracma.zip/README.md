# Kalabria Token - Presale Site (Dracma Style)

Sito HTML completo per la presale del Kalabria Token (KLB), in stile moneta dorata antica.

## Contenuto
- `index.html`
- `/images/logo.png`
- `README.md`

## Come usare
1. Carica tutto su un repo GitHub pubblico
2. Attiva GitHub Pages
3. Condividi il link alla community!
